<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Blog MVC</title>
</head>
<body>
    <h1>Proyecto Blog MVC</h1>
    <p>Aplicación web desarrollada con arquitectura MVC.</p>
</body>
</html>
