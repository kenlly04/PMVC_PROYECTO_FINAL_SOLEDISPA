<?php
class Post {
    private $id;
    private $title;
    private $content;
}
