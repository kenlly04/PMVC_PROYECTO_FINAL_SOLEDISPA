<?php
class PostController {
    public function index() {
        require_once 'app/views/posts.php';
    }
}
