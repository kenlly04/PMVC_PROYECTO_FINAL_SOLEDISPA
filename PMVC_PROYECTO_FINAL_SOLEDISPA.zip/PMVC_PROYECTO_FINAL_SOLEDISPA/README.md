# Proyecto Blog MVC

## Descripción
Aplicación web tipo blog desarrollada en PHP aplicando la arquitectura MVC.

## Tecnologías utilizadas
- PHP
- MySQL
- Docker
- GitHub
- Postman

## Instalación local (Docker)
docker-compose up

## URL de la aplicación desplegada
https://ejemplo.render.com

## Credenciales de usuario demo
demo@demo.com / 123456

## Diagrama ER
Definido en database/schema.sql

## Endpoints
GET /posts
